package com.example.dogedex.api.responses

import com.example.dogedex.api.dto.DogDTO

class DogListResponse (val dogs: List<DogDTO>)