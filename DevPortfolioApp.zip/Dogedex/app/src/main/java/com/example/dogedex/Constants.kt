package com.example.dogedex

const val BASE_URL = "https://todogs.herokuapp.com/api/v1/"
const val GET_ALL_DOGS = "dogs"
const val SIGN_UP_URL = "sign_up"