package com.example.dogedex.model

class User(
    val id: Long,
    val email: String,
    val authenticationToken: String
)