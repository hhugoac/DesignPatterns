package com.example.dogedex.api.responses

import com.example.dogedex.api.dto.UserDTO

class UserResponse(val user: UserDTO)